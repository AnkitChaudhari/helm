package com.company.regression.common;

public final class Config {

    private Config() {
    }

    public static String baseUrl() {
        return required("IQ_BASE_URL");
    }

    public static String username() {
        return required("IQ_USERNAME");
    }

    public static String password() {
        return required("IQ_PASSWORD");
    }

    public static String appPublicId() {
        return System.getenv("IQ_APP_ID");
    }

    private static String required(String key) {
        String val = System.getenv(key);
        if (val == null || val.isBlank()) {
            throw new IllegalStateException("Missing env var: " + key);
        }
        return val;
    }
}
