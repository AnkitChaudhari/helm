package com.company.regression.iq;

import com.company.regression.common.BaseTest;
import com.company.regression.common.Config;
import io.qameta.allure.Allure;
import io.qameta.allure.Description;
import io.qameta.allure.Step;
import io.restassured.response.Response;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import java.nio.charset.StandardCharsets;
import java.util.List;

import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class IQSmokeTests extends BaseTest {

    @Test
    @Order(1)
    @DisplayName("IQ Server is reachable and responding")
    @Description("Validates that the IQ Server root URL is reachable and returns HTTP 200 or 302.")
    void iqServerShouldBeReachable() {
        attachRequest("Root Endpoint Request", "GET", "/");

        Response response = callRootEndpoint();

        attachStatus("Root Endpoint Status", response);
        attachResponseHeaders("Root Endpoint Headers", response);
        attachResponse("Root Endpoint Response", response);

        assertThat(response.statusCode())
                .as("IQ Server root endpoint should return HTTP 200 or 302")
                .isIn(200, 302);
    }

    @Test
    @Order(2)
    @DisplayName("Authentication to IQ Server API works successfully")
    @Description("Validates that valid credentials can access the IQ applications API.")
    void authenticationShouldWork() {
        attachRequest("Authentication Check Request", "GET", "/api/v2/applications");

        Response response = callApplicationsApi();

        attachStatus("Authentication Check Status", response);
        attachResponseHeaders("Authentication Check Headers", response);
        attachResponse("Authentication Check Response", response);

        assertThat(response.statusCode())
                .as("Authentication using IQ credentials should return HTTP 200")
                .isEqualTo(200);
    }

    @Test
    @Order(3)
    @DisplayName("Applications API returns valid response")
    @Description("Validates that the IQ applications API is accessible and returns application data.")
    void applicationsApiShouldReturnData() {
        attachRequest("Applications API Request", "GET", "/api/v2/applications");

        Response response = callApplicationsApi();

        attachStatus("Applications API Status", response);
        attachResponseHeaders("Applications API Headers", response);
        attachResponse("Applications API Response", response);

        assertThat(response.statusCode())
                .as("Applications API should return HTTP 200")
                .isEqualTo(200);

        assertThat(response.asString())
                .as("Applications API response should contain applications field")
                .contains("applications");
    }

    @Test
    @Order(4)
    @DisplayName("Reports API is accessible and responding")
    @Description("Validates that the IQ reports API is reachable using valid credentials.")
    void reportsApiShouldWork() {
        attachRequest("Reports API Request", "GET", "/api/v2/reports/applications");

        Response response = callReportsApi();

        attachStatus("Reports API Status", response);
        attachResponseHeaders("Reports API Headers", response);
        attachResponse("Reports API Response", response);

        assertThat(response.statusCode())
                .as("Reports API should return HTTP 200")
                .isEqualTo(200);
    }

    @Test
    @Order(5)
    @DisplayName("Release stage evaluation exists for configured application")
    @Description("If IQ_APP_ID is configured, validates that the application exists and has at least one release-stage policy evaluation.")
    void releaseReportShouldExistIfAppConfigured() {
        String publicId = Config.appPublicId();

        if (publicId == null || publicId.isBlank()) {
            Allure.addAttachment("Execution Note", "Skipping report validation because IQ_APP_ID is not set.");
            return;
        }

        Allure.addAttachment("Configured IQ Application Public ID", publicId);

        attachRequest(
                "Application Lookup Request",
                "GET",
                "/api/v2/applications",
                "publicId=" + publicId
        );

        Response appResponse = findApplicationByPublicId(publicId);

        attachStatus("Application Lookup Status", appResponse);
        attachResponseHeaders("Application Lookup Headers", appResponse);
        attachResponse("Application Lookup Response", appResponse);

        List<Object> applications = appResponse.jsonPath().getList("applications");

        assertThat(applications)
                .as("Applications list for public ID '%s' should not be empty", publicId)
                .isNotNull()
                .isNotEmpty();

        String internalAppId = appResponse.jsonPath().getString("applications[0].id");

        assertThat(internalAppId)
                .as("Resolved internal application ID should not be blank")
                .isNotBlank();

        Allure.addAttachment("Resolved Internal Application ID", internalAppId);

        attachRequest(
                "Release Report History Request",
                "GET",
                "/api/v2/reports/applications/" + internalAppId + "/history",
                "stage=release, limit=1"
        );

        Response reportHistoryResponse = fetchReleaseReportHistory(internalAppId);

        attachStatus("Release Report History Status", reportHistoryResponse);
        attachResponseHeaders("Release Report History Headers", reportHistoryResponse);
        attachResponse("Release Report History Response", reportHistoryResponse);

        assertThat(reportHistoryResponse.statusCode())
                .as("Release report history API should return HTTP 200")
                .isEqualTo(200);

        assertThat(reportHistoryResponse.asString())
                .as("Release report history response should contain policyEvaluations")
                .contains("policyEvaluations");
    }

    @Step("Call IQ root endpoint")
    private Response callRootEndpoint() {
        return given()
                .when()
                .get("/");
    }

    @Step("Call IQ Applications API")
    private Response callApplicationsApi() {
        return given()
                .auth().preemptive().basic(username, password)
                .when()
                .get("/api/v2/applications");
    }

    @Step("Call IQ Reports API")
    private Response callReportsApi() {
        return given()
                .auth().preemptive().basic(username, password)
                .when()
                .get("/api/v2/reports/applications");
    }

    @Step("Find application by public ID: {publicId}")
    private Response findApplicationByPublicId(String publicId) {
        return given()
                .auth().preemptive().basic(username, password)
                .queryParam("publicId", publicId)
                .when()
                .get("/api/v2/applications");
    }

    @Step("Fetch release report history for internal application ID: {internalAppId}")
    private Response fetchReleaseReportHistory(String internalAppId) {
        return given()
                .auth().preemptive().basic(username, password)
                .queryParam("stage", "release")
                .queryParam("limit", 1)
                .when()
                .get("/api/v2/reports/applications/{id}/history", internalAppId);
    }

    @Step("Attach request details for: {name}")
    private void attachRequest(String name, String method, String path) {
        String content = "Method: " + method + "\n"
                + "Base URL: " + baseUrl + "\n"
                + "Path: " + path + "\n"
                + "Full URL: " + baseUrl + path;

        Allure.addAttachment(name, "text/plain", content, ".txt");
    }

    @Step("Attach request details for: {name}")
    private void attachRequest(String name, String method, String path, String queryDetails) {
        String content = "Method: " + method + "\n"
                + "Base URL: " + baseUrl + "\n"
                + "Path: " + path + "\n"
                + "Query: " + queryDetails + "\n"
                + "Full URL: " + baseUrl + path;

        Allure.addAttachment(name, "text/plain", content, ".txt");
    }

    @Step("Attach HTTP status for: {name}")
    private void attachStatus(String name, Response response) {
        Allure.addAttachment(name, "text/plain", String.valueOf(response.statusCode()), ".txt");
    }

    @Step("Attach response headers for: {name}")
    private void attachResponseHeaders(String name, Response response) {
        Allure.addAttachment(name, "text/plain", response.getHeaders().toString(), ".txt");
    }

    @Step("Attach response body for: {name}")
    private void attachResponse(String name, Response response) {
        String body;
        try {
            body = response.asPrettyString();
        } catch (Exception ex) {
            body = response.asString();
        }

        Allure.addAttachment(
                name,
                "application/json",
                new String(body.getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8),
                ".json"
        );
    }
}
