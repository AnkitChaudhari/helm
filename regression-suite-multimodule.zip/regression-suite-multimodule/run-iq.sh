#!/usr/bin/env bash
set -euo pipefail
mvn -pl iq-tests -am clean test
