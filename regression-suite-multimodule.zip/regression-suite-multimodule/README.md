# Regression Suite (Multi-Module Maven)

This starter project packages the existing Sonatype IQ regression/smoke suite into a multi-module Maven structure.

## Modules

- `regression-common` - shared config and base test setup
- `iq-tests` - Sonatype IQ smoke/regression tests with Allure attachments

## Required environment variables

```bash
export IQ_BASE_URL="https://your-iq-server.example.com"
export IQ_USERNAME="your-username"
export IQ_PASSWORD="your-password"
# Optional
export IQ_APP_ID="your-public-app-id"
```

## Run only IQ tests

```bash
mvn -pl iq-tests -am clean test
```

## Run from parent

```bash
mvn clean test
```

## Generate local Allure HTML report

```bash
mvn -pl iq-tests -am clean verify
```

Then open:

```text
iq-tests/target/site/allure-maven-plugin/index.html
```

## Surefire outputs

```text
iq-tests/target/surefire-reports/
```

## Allure raw outputs

```text
iq-tests/target/allure-results/
```
