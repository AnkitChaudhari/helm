# IQ Smoke Tests

Standalone Maven bundle for basic Sonatype IQ Server smoke testing.

## What it checks
- IQ server root endpoint is reachable
- Basic authentication works
- Applications API is responding
- Reports API is responding
- Optional: latest release-stage report exists for a configured application

## Required environment variables
```bash
export IQ_BASE_URL="https://iq.example.com"
export IQ_USERNAME="your-username"
export IQ_PASSWORD="your-password"
```

## Optional environment variable
```bash
export IQ_APP_ID="your-public-app-id"
```

If `IQ_APP_ID` is set, the suite also checks whether at least one release-stage policy evaluation exists for that application.

## Run locally
```bash
./run.sh
```

Or:
```bash
mvn test
```

## Output
JUnit/Surefire writes reports to:
```text
target/surefire-reports/
```

## Jenkins usage
Example pipeline step:
```groovy
stage('IQ Smoke Tests') {
  steps {
    sh 'mvn test'
  }
}

post {
  always {
    junit testResults: 'target/surefire-reports/*.xml', allowEmptyResults: false
    archiveArtifacts artifacts: 'target/surefire-reports/*', fingerprint: true
  }
}
```

## Notes
- The test bundle validates IQ server availability and core APIs.
- It does not trigger a new scan or policy evaluation by itself.
- For audit evidence, publish JUnit XML and archive the Surefire reports from your CI pipeline.
