#!/usr/bin/env bash
set -euo pipefail

echo "Running IQ smoke tests..."
mvn test
