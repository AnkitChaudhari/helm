package com.iq.smoke;

import io.restassured.RestAssured;
import org.junit.jupiter.api.BeforeAll;

public abstract class BaseTest {

    protected static String baseUrl;
    protected static String username;
    protected static String password;

    @BeforeAll
    static void setupBase() {
        baseUrl = Config.baseUrl();
        username = Config.username();
        password = Config.password();
        RestAssured.baseURI = baseUrl;
    }
}
