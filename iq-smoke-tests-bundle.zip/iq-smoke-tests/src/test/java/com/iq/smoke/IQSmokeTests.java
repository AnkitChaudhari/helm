package com.iq.smoke;

import io.restassured.response.Response;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class IQSmokeTests extends BaseTest {

    @Test
    @Order(1)
    void iqServerShouldBeReachable() {
        Response response = given()
                .when()
                .get("/");

        assertThat(response.statusCode())
                .as("IQ root endpoint status")
                .isIn(200, 302, 401, 403);
    }

    @Test
    @Order(2)
    void authenticationShouldWork() {
        Response response = given()
                .auth().preemptive().basic(username, password)
                .when()
                .get("/api/v2/applications");

        assertThat(response.statusCode())
                .as("Authentication via applications API")
                .isEqualTo(200);
    }

    @Test
    @Order(3)
    void applicationsApiShouldReturnApplicationsPayload() {
        Response response = given()
                .auth().preemptive().basic(username, password)
                .when()
                .get("/api/v2/applications");

        assertThat(response.statusCode())
                .as("Applications API status")
                .isEqualTo(200);

        assertThat(response.asString())
                .as("Applications API response body")
                .contains("applications");
    }

    @Test
    @Order(4)
    void reportsApiShouldRespond() {
        Response response = given()
                .auth().preemptive().basic(username, password)
                .when()
                .get("/api/v2/reports/applications");

        assertThat(response.statusCode())
                .as("Reports API status")
                .isIn(200, 404);
    }

    @Test
    @Order(5)
    @SuppressWarnings("unchecked")
    void releaseReportShouldExistIfAppConfigured() {
        String publicId = Config.appPublicId();
        if (publicId == null || publicId.isBlank()) {
            System.out.println("Skipping report validation because IQ_APP_ID is not set.");
            return;
        }

        Response appResponse = given()
                .auth().preemptive().basic(username, password)
                .queryParam("publicId", publicId)
                .when()
                .get("/api/v2/applications");

        assertThat(appResponse.statusCode())
                .as("Application lookup by publicId")
                .isEqualTo(200);

        Map<String, Object> applicationBody = appResponse.as(Map.class);
        List<Map<String, Object>> applications = (List<Map<String, Object>>) applicationBody.get("applications");

        assertThat(applications)
                .as("Applications returned for publicId")
                .isNotNull()
                .isNotEmpty();

        String internalId = String.valueOf(applications.get(0).get("id"));

        Response reportHistoryResponse = given()
                .auth().preemptive().basic(username, password)
                .queryParam("stage", "release")
                .queryParam("limit", 1)
                .when()
                .get("/api/v2/reports/applications/{id}/history", internalId);

        assertThat(reportHistoryResponse.statusCode())
                .as("Release-stage report history API status")
                .isEqualTo(200);

        assertThat(reportHistoryResponse.asString())
                .as("Report history response body")
                .contains("policyEvaluations");
    }
}
