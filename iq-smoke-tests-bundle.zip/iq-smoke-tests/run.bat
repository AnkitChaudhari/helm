@echo off
setlocal

echo Running IQ smoke tests...
mvn test
